# Changelog

Each release lists what a running project must do to adopt it. Update between stages, never during a task (see `guide/cheatsheet.md`). The current version is in `VERSION`; projects record theirs in `board.json` → `generator_version`.

## 1.1.0

**Orchestration on top of the plan.** 1.0 planned a project and guarded the writes, but it could not say what had been tried, when a review happened or whether a risky action was approved. The board was the only record, so a status could simply be typed in; attempts, review rounds and emergency stops lived in chat. 1.1 separates plan state from execution state and puts a checkpoint before every transition. A project without `policy.json` keeps the 1.0 behaviour: the new checks warn instead of failing.

**Policy as code (`policy.json`).**
- New `templates/policy.json` and `core/policy.py`: limits (`max_attempts_per_task`, `max_in_progress`, `max_review_rounds`, with ranges 1–10, 1–64, 1–20), `scope.protected_paths`, `dependencies` (approval switch + manifest list), `approvals` (actions + approver), `commands` (deny, lead_only, warn) and `checks` (review/handoff/run-record/disjoint-scopes).
- Loading deep-merges the defaults; unknown keys, a wrong `version` or out-of-range limits are errors. An absent file means `enabled: false`, which is what keeps 0.9 and 1.0 projects unchanged.
- Path matching is `**`-aware and basename matching applies at any depth; command matching strips quotes, heredocs, assignments and wrappers, joins the shell segments and matches the pattern against them.
- `tools/check.py` validates the policy; a policy that denies a command a gate needs is a planning error, not an approval.

**Checkpoints (`tools/state.py`, `core/state.py`).**
- `tools/state.py show | set | check`: the only writer of a task's status. `show` prints the board status against the run record, gates, review, approvals and attempts; `check` evaluates a transition without writing; `set` refuses with each blocker and an action hint.
- Transition table with hard preconditions: `in_progress` needs a free attempt, a free `in_progress` slot and an unblocked stage; `verifying` an open attempt; `review` a passing record for every gate in the task; `done` the review verdict, handoff, run record and a dependency approval when a manifest is touched; `rework` a note and a free round; `blocked`/`failed` a note; `done → rework` a granted `reopen_done` approval; `--force` a granted `state_override` approval and leaves a warning event.
- Side effects: atomic board write, run-record attempts and events, round increment on `rework`, no other files.

**Run records (`runs/<ID>.json`, `core/runs.py`).**
- One file per task: `state` (`idle | running | done | failed | blocked`), `attempt` counter, `attempts` (`pass | fail | cancelled`) and an append-only `events` list (`start`, `gate`, `review`, `state`, `approval`, `note`, `escalate`; last 500 kept). Written atomically under `<file>.lock`; a missing or broken file reads as a skeleton.
- `tools/gate.py` appends a `gate` event when the policy is enabled; a failure there never changes the gate result. `runs/` is committed with the task.

**Approvals (`reviews/approvals/AP-NNN.json`, `core/approvals.py`).**
- New `tools/approve.py request | grant | deny | list | check`: IDs `AP-` plus three or more digits, allocated under a lock. A granted record is the approval and does not expire; grant and deny append an `approval` event to the task's run record. `check --action ... --task ...` exits 0 only for a granted match.
- Actions: `new_dependency`, `scope_change`, `merge_to_base`, `release`, `reopen_done`, `protected_path`, `state_override` — the list lives in `policy.json`. The guard consumes the dependency approval; a protected path is lead-only, so no approval lets a worker write one.

**Dispatch (`tools/dispatch.py`, `core/dispatch.py`).**
- The board becomes an execution plan: `limits`, `running` with attempt N/M, `waves` of tasks with the same non-empty `parallel_group`, same stage and pairwise disjoint `scope_write` (packed up to `max_in_progress`), `blocked` tasks with the command that records the block, `conflicts`, `approvals_pending` and `next`.
- A task without a group is a wave of its own; an attempt-exhausted task, a task without a brief, a task claimed by another session and a task waiting for a dependency or a stopped stage are listed as blocked, each with the command that records the block. With `checks.disjoint_scopes: false` both overlapping tasks stay in the wave and the conflict is still listed.

**Audit (`tools/audit.py`, `core/audit.py`).**
- Per task: board status, attempts used/limit, gates, review file and verdict, approvals per action, handoff, run record, findings. For a `done` task every check the policy turns on is an error; for other statuses the findings are warnings, and without `policy.json` everything stays a warning. Exit 1 iff any error.

**Checks and status.**
- `tools/check.py`: validates `policy.json`, `reviews/approvals/` and `runs/`, flags two `in_progress` tasks with overlapping scopes and attempts above the limit, reports dispatch conflicts as errors and blocked tasks as warnings, and warns when `policy.json`, `docs/orchestration.md` or `runs/` are not named in `AGENTS.md`/`README.md`.
- `tools/render_status.py`: new "Orchestration" section (limits, next wave, running attempts, blocked tasks with reasons, pending approvals), at most 10 lines.
- `core/board.py`: the stage report gains `tasks_open`; a stage is complete only when no task in it is open.
- `core/scope.py`: `runs/` is lead-owned and a reviewer may not write `reviews/approvals/`.

**Guard and plugin.**
- The DSH guard and the Claude Code `PreToolUse` hook apply the policy after the role and scope rules: a protected path is refused to every session except a lead, a dependency manifest needs a granted `new_dependency` approval, denied commands are refused for every role, lead-only commands for worker and reviewer sessions. Lead sessions bypass the path and dependency checks; nobody bypasses a deny rule.
- New `pl_next` (dispatch plan as JSON) and `pl_state` (`show`/`set` through `tools/state.py`); `/pl next` and `/pl policy`. New `adapters/dsh/lib/policy.mjs`, tested against `core/tests/policy_cases.json` together with `core/policy.py`.

**Docs and templates.**
- New `prompt/orchestration.md`: the shipped model — plan, execution and liveness state, the task loop, the stage loop, checkpoints, attempts versus rounds, approvals, escalation, how board patterns map and what is not covered.
- New `templates/policy.json` and `templates/orchestration.md` (generated as `docs/orchestration.md`); `templates/AGENTS.template.md` gains the state/gate/approval/run rules, `templates/task-brief.md` an "Operating the task" line, `templates/review-feedback.md` the round rule.
- `prompt/generator.md`: limits per profile in phase 0.3, `policy.json` in phase D, the loop, approvals and escalation in phase E, the new files in the G scaffold, `audit.py` and `dispatch.py` in phase H, the orchestrate prompt and state/approval commands in phase I, plus definitions and artifact-map rows.
- `prompt/rubric.md`: criteria 14 (execution state) and 15 (policy and approvals), the 1.1 lint items, critic and cold-start updates. `prompt/dsh.md`, `SKILL.md`, `guide/cheatsheet.md` and `README.md` describe the loop and the new tools.

**Compatibility.** Additive, and a project without `policy.json` is not broken by 1.1. Both 0.9 and 1.0 boards are unchanged, `board.json` keeps its schema (1.1 adds no board field), and `check.py`/`audit.py` warn instead of failing; the guard adds no policy denials. A project that runs `tools/state.py` without a policy still gets the transition table, the note rules and the approvals that guard a reopened done task or a forced change; the gate, review, attempt and concurrency checks become warnings, and the dependency-manifest approval is not checked. `examples/minimal-cli` stays the 0.9 compatibility reference; `examples/monorepo-mini` is the 1.1 reference. Existing tools, plugin tools, `/pl` commands and board fields are unchanged. The core gains `core/policy.py`, `core/runs.py`, `core/approvals.py`, `core/state.py`, `core/dispatch.py` and `core/audit.py`; `tools/` gains `state.py`, `approve.py`, `dispatch.py` and `audit.py`.

**Migration:** 0.9 and 1.0 projects need nothing. To adopt 1.1: copy `policy.json` from `templates/policy.json` and set the limits for the profile (S 3/1/3, M 3/2/3, L 3/3/3 for attempts/in progress/rounds), the project's manifests and its protected paths; copy `docs/orchestration.md` from the template; add the state, gate, approval and runs rules from `templates/AGENTS.template.md` to `AGENTS.md`; name `policy.json`, `runs/` and `docs/orchestration.md` in `AGENTS.md` and `README.md`; commit `runs/` from the next task on. From then on set statuses only with `tools/state.py set` and approve high-risk actions with `tools/approve.py`. Plugin users: `git pull` in the clone, run `dsh plugin --profile <name> add ./polier` again and restart. Claude Code users: replace the package copy; the hook applies the same policy checks. Skill-only users: `./update.sh`. Until `policy.json` exists, `check.py` stays green with the 1.0 result and the project keeps working; `examples/minimal-cli` is the 0.9 compatibility reference, `examples/monorepo-mini` the 1.1 reference.

## 1.0.0

**Parallel projects and monorepos.** 0.9 planned and guarded one project with one active writer well. Running a real project with two harnesses in parallel and planning a monorepo exposed gaps that file-scope guarding cannot catch: shared ports and test databases, gate runs that fail because another session holds a port, snapshots that look like flaky tests, releases from a working folder, missing environment variables, and no common record of who works on what.

**Board 1.0.** `board.json` gets `"schema_version": "1.0"` (opt-in; a 0.9 board omits it and stays valid). Validation is strict per version: a 1.0 field on a 0.9 board is an error that says to set the version, unknown fields are errors.
- Task IDs widen from `M03` to also `P3-02`, `ENG-14`; new optional task fields `package`, `exclusive`, `resources`, `claim` (tooling only), `contract_followups`.
- New board fields: `stages` (exit criteria, exit gates, owner decision, dependencies), `packages` (path, kind, `may_import`), `resources` (slots, port formula, service offsets, `infra_patterns`), `budgets`, `worktrees`, `contracts`.
- `stage` on a task may reference `stages[].id`. `render_status.py` shows per stage: state, exit gates, missing records, owner decision; plus packages and the runtime slot formula. Later-stage tasks are not "ready" while a blocking stage is incomplete, and `check.py` rejects `in_progress` work there.

**Runtime slots and exclusive gates.** Two worktrees can run servers and tests at the same time.
- New `tools/slot.py acquire | release | show | list` and `core/slots.py`: slot 0 is the owner's main checkout, worktrees get the lowest free slot, `.polier-slot` holds ports (`port_base + port_stride·N + service offset`), database name and bucket; registered in `<git-common-dir>/polier/slots.json`.
- `tools/gate.py --exclusive <resource>` (and automatically for a task's `exclusive`) locks the resource in `<git-common-dir>/polier/locks/`; `--lock-wait`/`--lock-ttl`, exit 75 and `result: busy` when it stays held. `pl_gate` honours the same lock.
- Records gain `slot`, `exclusive`, `lock_wait_s`, `result` (`pass | fail | timeout | busy | infra`) and a stale-lock warning. Infrastructure patterns (`ECONNREFUSED`, `EADDRINUSE`, project patterns) are recorded as `infra`; `check.py` rejects `infra`/`busy`/`timeout` records as evidence and says "infrastructure failure, rerun alone" instead of "gate failed".

**Claims and worktrees.** One live session per task, across harnesses.
- New `tools/claim.py take | release | beat | list` and `core/claims.py`: claims in `<git-common-dir>/polier/claims/<task>.json`, live while the heartbeat is younger than 10 minutes. `board.json` is never written by claims. DSH `/pl task` claims and refreshes the heartbeat at most once a minute; `pl_status` lists live claims. Claude Code takes/refreshes the claim when `POLIER_TASK` is set and denies a write while another live session holds the task.
- New `tools/worktree.py start | finish` and `core/scope.py` worktree rule: `worktrees: required` (default at M/L on a 1.0 board; a 0.9 board stays `recommended`) denies a worker write in the main checkout while its task has a worktree ("work in <worktree path>"). `start` creates branch, slot and claim in one step; `finish` refuses uncommitted changes.
- The stop check reports changed files inside another live claim's scope as "foreign changes (task X, harness Y)" instead of blaming the current task. They never block.

**Profile L: monorepo.** Several deployable parts or packages with their own builds, integrated through contracts; L requires `packages`.
- New templates `monorepo-layout.md`, `package-ARCHITECTURE.md`, `package-AGENTS.md`, `contract.md`, `releasing.md`, `environments.md`, `versions.md`, `design-rules.md` and `gates/*.md` (Node/TS, Python, C++/CMake, WASM/Emscripten, Postgres, Playwright, visual diff, load).
- Root `ARCHITECTURE.md` states the system shape; each package gets `ARCHITECTURE.md` (≤ 400 words) and optional `AGENTS.md` (≤ 200); `docs/module-map.md` becomes the package map; briefs list root files plus the package's own files; package files only for packages created in the current stage.
- `check.py` checks package folders, package files, task scopes inside their package (contract paths excepted), a missing or unpinned `docs/versions.md`, and an environment without a smoke URL.
- New `tools/boundaries.py`: import boundaries from `packages[].may_import`, TS/JS/Python/C++ imports, `tsconfig` path aliases; exit 0/1/2; offered as gate `boundaries`.
- New `tools/contracts.py check | list`: JSON Schema 2020-12 contracts with valid/invalid fixtures, SemVer rules (major for a removed or renamed field), dependants and `contract_followups`.
- Profile-dependent budgets replace ad-hoc overrides: architecture 600/700/800, AGENTS 300/350/400, STATUS 300/500/900, briefs 800/800/900, package files 400/200. A board override needs a `reason`.

**Release and smoke.** `templates/releasing.md` and `templates/environments.md` describe trunk-based flow, tags, CI-only release, rollback and the environment × variable checklist (names only). New `tools/release_check.py` (dirty tree, untagged HEAD, tag not on the base branch, released-stage tasks not done; `--allow-untagged` for previews) as gate `release-clean`, and `tools/smoke.py` (URL status paths, headers only as `--header "Name: env:VARIABLE"`, recorded via `gate.py`). Generated `AGENTS.md` says: agents never publish; releases run in CI from tags.

**UI briefs.** `templates/task-brief.md` has an optional "UI specification" section: target values in px/ms/tokens, all applicable states, "do not", screenshot evidence. `templates/design-rules.md` is the binding token/state/accessibility reference. The rubric has a 13th criterion: a UI task without target values fails.

**Drift detection.** `tools/manifest.json` lists the SHA-256 of every shipped file; `tools/drift.py` compares the project-local copy (`.generator/`) with it and `update.sh` prints the drift report (the files that differ) before updating. `check.py` warns "local edits or outdated copy" and names the files. Extra files next to the copy are ignored.

**Guard extras.** `kill`, `pkill`, `killall` and `xargs kill` in a worker command get a warning (Claude Code: `ask`; DSH: one message per turn) — never a denial. Guarded paths compare case-insensitively on macOS and Windows, where the file system does.

**Compatibility.** No field removed; a valid 0.9 board still validates and `check.py` reports the version difference as a migration warning. Validation is now strict per schema version, so unknown fields are errors — a board with invented fields drops them or moves them anywhere outside `board.json`. `drift.py`, `slot.py`, `claim.py`, `worktree.py`, `boundaries.py`, `contracts.py`, `release_check.py`, `smoke.py` and `manifest.py` are additive. The core gains `core/slots.py`, `core/locks.py`, `core/claims.py` and `core/boundaries.py`; the DSH guard mirror in `adapters/dsh/lib/project.mjs` gains the worktree rule, case-insensitive comparison and kill detection, tested against `core/tests/write_cases.json`.

**Migration:** S and M projects need nothing. To adopt the new features: add `resources` to the board, `.polier-slot` to `.gitignore` and a `tools/dev/setup` that reads `.polier-slot`; add `"exclusive": ["e2e"]` (or `db`, `load`) to tasks whose gates share a resource; at M/L a 1.0 board defaults `worktrees` to `required`, while a 0.9 board stays on `recommended`, so an existing project is unchanged until the owner sets `required` after migrating. L projects: set `"schema_version": "1.0"`, add `packages[]` (with `may_import`), `stages[]` and `resources`, move to one package per folder with `ARCHITECTURE.md` and optional `AGENTS.md`, declare `contracts[]` with schemas and fixtures, and use `worktrees: required`. Plugin users: `git pull` in the clone, run `dsh plugin --profile <name> add ./polier` again and restart; one update is needed to get `tools/manifest.json` for drift detection. Claude Code users: replace the package copy (`./install.sh claude` or `./update.sh claude`); the hook entries stay the same, set `POLIER_TASK` so the hook claims the task (a second live claim now denies writes), and expect `ask` on process-killing commands and foreign changes in the stop message. Skill-only users: `./update.sh`; reinstall once for the manifest. Projects still on 0.9: `check.py` under 1.0 passes or prints only migration warnings (generator version, missing manifest), and schema errors only appear when a 1.0 field is used without `schema_version`.

## 0.9.0

**Core split from the harness.** The enforcement rules now live in `core/`, a Python package without any DeepSeek Harness code, so later adapters (Claude Code, git hooks) can use the same rules.

- `core/`: `check_write` (guard decision), `check_stop` and `scope_check` (changed files against a task), `run_gate` (gate records), `verify_evidence`, `load_board`, `pick_task`, `active_tasks`, `ready_tasks`. Python 3.9+, standard library only, own tests in `core/tests/`.
- The DSH plugin moved from `dsh/` to `adapters/dsh/`; `package.json` points there. Its synchronous guard keeps a JavaScript mirror of `check_write`; both are tested against one decision table, `core/tests/write_cases.json`.
- `tools/gate.py`, `tools/scope_check.py` and `tools/check.py` are thin command-line wrappers around `core/`; paths, options, output and exit codes are unchanged.
- **Claude Code adapter** in `adapters/claude-code/`: a `PreToolUse` hook checks `Write`, `Edit`, `MultiEdit`, `NotebookEdit` and the files a `Bash` command visibly writes (new `core/shell.py`); a `Stop` hook runs the stop check and sends violations back to Claude. Roles and settings come from `POLIER_*` environment variables. Example `settings.example.json`, install guide and tests with simulated hook events.
- README lists what the guard does not cover.
- `install.sh` no longer copies `__pycache__` folders and leaves out the new test folders.
- Unchanged: plugin behaviour, tool names, `/pl`, messages, `board.json` fields. The guard and the stop check keep their slightly different rule order (the guard lets `reviews/evidence/` through before `scope_write_forbidden`, the stop check checks `scope_write_forbidden` first).

**Migration:** set `generator_version` to `0.9.0`. Plugin users: `git pull` in the clone, then run `dsh plugin --profile <name> add ./polier` again and restart the harness. Skill-only users: `./update.sh`. Projects that call `tools/gate.py` keep working. Claude Code: optional, see `adapters/claude-code/README.md`.

## 0.8.0

**Renamed to Polier.** The project was the "Prompt Generator"; it now plans and enforces, so it is called Polier (German for site foreman).

- Repository `atshv/polier` (GitHub redirects the old `atshv/prompt-generator`), package `dsh-polier`, plugin row and skill `polier`.
- Tools `pl_status`, `pl_gate`, `pl_scope_check`, `pl_check` (were `pg_*`); human command `/pl` (was `/pg`).
- Messages start with `Polier:`. `install.sh` and `update.sh` install the skill as `polier`.
- Unchanged: file layout, `board.json` fields (including `generator_version`), the Python tools and their output.

**Migration:** set `generator_version` to `0.8.0`. In each project's `AGENTS.md`, replace `pg_gate` with `pl_gate` (and any other `pg_*`). Plugin users: `dsh plugin --profile <name> remove dsh-prompt-generator`, then `dsh plugin --profile <name> add ./polier`. Skill-only users: delete `~/.dsh/skills/prompt-generator/` and run `./install.sh` again. Use `/pl` instead of `/pg`.

## 0.7.1

- Plugin: `/pg reviewer` makes a session write only under `reviews/` (with or without a running task).
- `prompt/generator.md`: tool check detects the plugin; the gate rule in `AGENTS.md` names `pg_gate` or the real `gate.py` path; the human checklist sets each task `in_progress` before the worker starts; start and review prompts use `pg_status`, `pg_gate`, `pg_scope_check` and gate records.
- `guide/cheatsheet.md`: new "Before every task" checklist, evidence and `/pg` steps after every task, red flags for the guard.
- GitHub workflow runs `npm test` and `check.py` on the example for every push to `main` and every pull request.
- Example: gate rule in `AGENTS.md` updated; leftover `brief.md` and `review-feedback.md` removed (`project-input.md` and `reviews/M03.md` are the current versions).

**Migration:** set `generator_version` to `0.7.1`. Optional: take the new gate rule from `templates/AGENTS.template.md`; use `/pg reviewer` for review sessions.

## 0.7.0

**DeepSeek Harness plugin.** The package is now also an installable DSH plugin (`dsh plugin --profile <name> add …`, see `README.md`). It registers the skill with its files resolved inside the package and adds:

- a write guard: while a task is `in_progress`, a worker session may write only inside that task's `scope_write` (minus `scope_write_forbidden`); `board.json`, `STATUS.md` and `tasks/` are lead-owned, `reviews/evidence/` is always writable. Config `enforce: deny | ask | off`.
- a stop check: before a turn ends, the git diff is compared with the scope. Out-of-scope changes, including those made through `bash`, are sent back to the agent (max. 2 reminders per turn).
- tools `pg_status`, `pg_gate`, `pg_scope_check`, `pg_check`.
- the human command `/pg` (`status`, `lead`, `worker`, `off`, `task <ID>`, `render`). Roles live in memory; after a harness restart every session is a worker again.

**Tools.**

- New `tools/scope_check.py`: changed files (modified, staged, untracked, deleted, both sides of a rename) against the running task's scope. Exit 0/1/2, `--json`.
- `tools/gate.py` writes a new log and a JSON record per run (command, exit code, times, commit, dirty flag, SHA-256 of the log) and never overwrites. The last output line is `record: <path>`. New `--shell "<command>"`.
- `tools/check.py` verifies records for `done` tasks: file exists, belongs to the task, log unchanged, exit code 0, every listed gate covered. A record made on a commit outside `HEAD`'s history warns. Free-text evidence only warns.
- Earlier in this cycle: `install.sh` uses `tar` instead of `rsync`; optional `handoff` per task, shown by `render_status.py` under "Ready now"; `check.py` warns on `STATUS.md` over 300 words, context packs over about 15k tokens and done tasks without handoff.
- Tests: `npm test` (plugin against the real DSH tool registry, Python `unittest` for the tools).

**Migration:** set `generator_version` to `0.7.0`. Replace the gate line in `AGENTS.md` with the one from `templates/AGENTS.template.md`. From now on put the record paths from `gate.py`/`pg_gate` into `evidence`; old free-text evidence keeps passing with a warning. Commit `reviews/evidence/`. To use the plugin, install it and use `/pg lead` in sessions that plan, merge or edit the board.

## 0.6.0

- Package reorganised: `prompt/` (generator, rubric, DSH mapping), `guide/` (cheatsheet), root keeps entry points (`SKILL.md`, `README.md`, `CHANGELOG.md`, `VERSION`, `install.sh`, `update.sh`).
- `prompt/generator.md` states which paths belong to the package and which to the project.

**Migration:** projects: set `generator_version` to `0.6.0`. Chat users: attach `prompt/generator.md` and `prompt/rubric.md` instead of the root files. Skill installs: run `./update.sh`.

## 0.5.6

- `install.sh` and `update.sh` accept the target `claude` (`~/.claude/skills`) for Claude Code; DSH stays the default.

**Migration:** set `generator_version` to `0.5.6`.

## 0.5.5

- `install.sh` and `update.sh` target the DeepSeek Harness only (`~/.dsh/skills` or a given path).

**Migration:** set `generator_version` to `0.5.5`.

## 0.5.4

- `install.sh` and `update.sh` install, update or roll back the skill from the shell, optionally pinned to a tag.

**Migration:** set `generator_version` to `0.5.4`.

## 0.5.3

- `STATUS.md` starts with a "Ready now" list: pending tasks whose dependencies are done.
- `check.py` rejects `done` tasks without `evidence`.
- Interview questions offer a recommended default first.
- `board.json` records `generator_version`; `check.py` warns when it differs from the package.

**Migration:** add `"generator_version": "0.5.3"` to `board.json`; fill `evidence` for every `done` task; run `render_status.py`.

## 0.5.2

- `dsh.md` maps every phase to a DeepSeek Harness tool, with fallbacks; install as a DSH skill.
- All documents tightened; no rule changed.

**Migration:** none.

## 0.5.1

- `SKILL.md` entry point for installation as an agent skill.
- `check.py` cross-checks artifacts: briefs match their board entry (ID, title, acceptance IDs, `**Scope:**` line, `satisfies`), every `AD-n`/`ADR-nnnn` reference exists, `STATUS.md` matches `board.json`.
- Traceability: definition-of-done items `D1..Dn` in `docs/quality.md`, covered by the new task field `satisfies`.

**Migration:** run `render_status.py`; align briefs with the board; optionally number the definition of done and add `satisfies` (without D-IDs, `check.py` only warns).

## 0.5.0

- Package translated to English; default project language English.
- Reviews stored in `reviews/<ID>.md`; briefs always `tasks/<ID>.md`.
- `check.py` requires `.gitignore` and `base_branch`; layer names in `docs/module-map.md` are checked in English (UI, logic, data).

**Migration:** projects from 0.4 keep running with the 0.4 package; switching requires English layer names in `docs/module-map.md`, a `.gitignore`, and moving review files to `reviews/`.

## 0.4.0

German original.
